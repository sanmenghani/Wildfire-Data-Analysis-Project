spark-submit --master "local[*]" --class edu.ucr.cs.cs167.bchau010.Task1 ./target/bchau010_lab10-1.0-SNAPSHOT.jar ./convert wildfiredb_100k.csv convertd100k
spark-submit --master "local[*]" --class edu.ucr.cs.cs167.bchau010.Task2 ./target/bchau010_lab10-1.0-SNAPSHOT.jar ./wildfiredb_sample.parquet
spark-submit --master "local[*]" --class edu.ucr.cs.cs167.bchau010.Task3 ./target/bchau010_lab10-1.0-SNAPSHOT.jar
spark-submit --master "local[*]" --class edu.ucr.cs.cs167.bchau010.Task4 ./target/bchau010_lab10-1.0-SNAPSHOT.jar ./wildfiredb_sample.parquet
