package edu.ucr.cs.cs167.bchau010

import org.apache.spark.SparkConf
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.feature.{HashingTF, VectorAssembler, StringIndexer, Tokenizer, StandardScaler}
import org.apache.spark.ml.param.ParamMap
import org.apache.spark.ml.tuning.{ParamGridBuilder, TrainValidationSplit, TrainValidationSplitModel}
import org.apache.spark.ml.{Pipeline, PipelineModel}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.sql.functions.{avg, sum, when, col}

object Task4 {

  def main(args : Array[String]) {
    if (args.length != 1) {
      println("Usage <input file>")
      println("  - <input file> path to a Parquet file input")
      sys.exit(0)
    }
    val inputfile = args(0)
    val conf = new SparkConf
    if (!conf.contains("spark.master"))
      conf.setMaster("local[*]")
    println(s"Using Spark master '${conf.get("spark.master")}'")

    val spark = SparkSession
      .builder()
      .appName("Fire Intensity Prediction")
      .config(conf)
      .getOrCreate()

    val t1 = System.nanoTime
    try {
      // process data
      val df: DataFrame = spark.read.parquet(inputfile)
      //df.printSchema()

      // aggregate
      val adf = df.groupBy("County")
        .agg(
          sum("frp_float").alias("fire_intensity"),
          avg("ELEV_mean").alias("ELEV_mean"),
          avg("SLP_mean").alias("SLP_mean"),
          avg("EVT_mean").alias("EVT_mean"),
          avg("EVH_mean").alias("EVH_mean"),
          avg("CH_mean").alias("CH_mean"),
          avg("TEMP_ave").alias("TEMP_ave"),
          avg("TEMP_min").alias("TEMP_min"),
          avg("TEMP_max").alias("TEMP_max")
        )

      val labeleddf = adf.withColumn("label", when(col("fire_intensity") > 2.6, 1).otherwise(0))

      val featureCols = Array("ELEV_mean", "SLP_mean", "EVT_mean", "EVH_mean", "CH_mean", "TEMP_ave", "TEMP_min", "TEMP_max")
      val assembler = new VectorAssembler()
        .setInputCols(featureCols)
        .setOutputCol("features")

      // normalize
      val scaler = new StandardScaler()
        .setInputCol("features")
        .setOutputCol("scaledFeatures")
        .setWithStd(true)
        .setWithMean(true)

      // logistic regression model
      val lr = new LogisticRegression()
        .setLabelCol("label")
        .setFeaturesCol("scaledFeatures")

      val pipeline = new Pipeline()
        .setStages(Array(assembler, scaler, lr))

      val Array(trainData, testData) = labeleddf.randomSplit(Array(0.8, 0.2), seed = 1234)

      val model = pipeline.fit(trainData)

      val predictions = model.transform(testData)

      val result = predictions.select("ELEV_mean", "SLP_mean", "EVT_mean", "EVH_mean", "CH_mean", "TEMP_ave", "TEMP_min", "TEMP_max", "fire_intensity", "prediction")
      result.show()

      val evaluator = new RegressionEvaluator()
        .setLabelCol("label")
        .setPredictionCol("prediction")
        .setMetricName("rmse")

      val rmse = evaluator.evaluate(predictions)
      println(s"Root Mean Squared Error (RMSE) for $inputfile: $rmse")

      val t2 = System.nanoTime
      println(s"Time it took to create model for $inputfile: ${(t2 - t1) * 1E-9} seconds")
    } finally {
      spark.stop
    }
  }
}
