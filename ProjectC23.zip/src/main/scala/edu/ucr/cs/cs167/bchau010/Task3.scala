package edu.ucr.cs.cs167.dbiro001

import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.beast.{CRSServer, SparkSQLRegistration}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions.{col, sum, year, month}
import java.text.SimpleDateFormat
import java.util.Calendar


/**
 * Scala examples for Beast
 */
object Task3 {
  def main(args: Array[String]): Unit = {
    // Check if the county name is provided as a command-line argument
    if (args.length < 1) {
      println("Must provide county name!")
      sys.exit(1)
    }

    // read in county name from command line argument
    val countyName = args(0)

    // Suppress INFO messages from Spark
    Logger.getLogger("org").setLevel(Level.ERROR)
    Logger.getLogger("akka").setLevel(Level.ERROR)


    // Initialize Spark context
    val conf = new SparkConf().setAppName("Beast Example")
    // Set Spark master to local if not already set
    if (!conf.contains("spark.master"))
      conf.setMaster("local[*]")

    // Start the CRSServer and store the information in SparkConf
    val sparkSession: SparkSession = SparkSession.builder().config(conf).getOrCreate()
    val sparkContext = sparkSession.sparkContext
    CRSServer.startServer(sparkContext)
    SparkSQLRegistration.registerUDT
    SparkSQLRegistration.registerUDF(sparkSession)

    try {
      // Import Beast features
      import edu.ucr.cs.bdlab.beast._

      // Read the Parquet file into a DataFrame
      val wildfireDF = sparkSession.read.parquet("wildfire_100k.parquet")
      println("wildfireDF:")
      wildfireDF.show()
      // Filter county data by county name and California state code (STATEFP="06")
      val filteredCountyDF = countyDF.filter(col("NAME") === countyName && col("STATEFP") === "06")
      println("filteredCountyDF:")


      // Check if the county exists
      if (filteredCountyDF.isEmpty) {
        println(s"County '$countyName' not found in California.")
        sys.exit(1)
      }
      else{
        filteredCountyDF.show()
      }

      // Get the GEOID of the selected county
      val geoId = filteredCountyDF.select("GEOID").first().getString(0)
      println("geoID of selected county:")
      println(geoId)

      // Filter wildfire data by county GEOID
      val filteredWildfireDF = wildfireDF.filter(col("County") === geoId)
      println("filteredWildfireDF:")
      filteredWildfireDF.show()

      // Group filtered wildfire data by year and month, compute total fire intensity, and sort by year and month
      val resultDF = filteredWildfireDF
        .withColumn("year", year(col("acq_date")))
        .withColumn("month", month(col("acq_date")))
        .groupBy("year", "month")
        .agg(sum("frp_float").alias("total_fire_intensity"))
        .orderBy("year", "month")

      println("resultDF:")
      resultDF.show()

    } finally {
      sparkSession.stop()
    }
  }
}