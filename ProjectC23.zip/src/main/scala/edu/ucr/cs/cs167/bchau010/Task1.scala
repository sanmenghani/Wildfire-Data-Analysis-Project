package edu.ucr.cs.cs167.smeng025

import edu.ucr.cs.bdlab.beast.geolite.{Feature, IFeature}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.beast.SparkSQLRegistration
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions.{col, split, when}
import org.apache.log4j.{Level, LogManager}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.functions._



/**
 * Scala examples for Beast
 */
object Task1 {
  def main(args: Array[String]): Unit = {
    // Initialize Spark context

    val conf = new SparkConf().setAppName("Beast Example")
    // Set Spark master to local if not already set
    if (!conf.contains("spark.master"))
      conf.setMaster("local[*]")

    // Start the CRSServer and store the information in SparkConf
    val sparkSession: SparkSession = SparkSession.builder().config(conf).getOrCreate()
    val sparkContext = sparkSession.sparkContext
    SparkSQLRegistration.registerUDT
    SparkSQLRegistration.registerUDF(sparkSession)

    val operation: String = args(0)
    val inputFile: String = args(1)

    try {
      // Import Beast features
      import edu.ucr.cs.bdlab.beast._
      val t1 = System.nanoTime()
      var validOperation = true

      operation match {
        case "convert" =>
          val outputFile = args(2)

          val wildfireDF = sparkSession.read.format("csv")
            .option("sep", "\t")
            .option("inferSchema", "true")
            .option("header", "true")
            .load(inputFile)
            .select(
              "x", "y", "acq_date", "frp", "acq_time",
              "ELEV_mean", "SLP_mean", "EVT_mean", "EVH_mean", "CH_mean",
              "TEMP_ave", "TEMP_min", "TEMP_max"
            )

          wildfireDF.createOrReplaceTempView("wildfire")

          //introducing geometry attribute ST_CreatePoint
          wildfireDF.selectExpr("*", "ST_CreatePoint(x, y) AS geometry")


          //separate two values in frp column and move to frp_float column
          //cast num columns to doubles
          val wildfiresWithFrp = wildfireDF
            .withColumn("frp_float", when(col("frp").contains(","), split(col("frp"), ",")(0)).otherwise(col("frp")).cast("double"))
            .drop("frp")
            .withColumn("ELEV_mean", col("ELEV_mean").cast("double"))
            .withColumn("SLP_mean", col("SLP_mean").cast("double"))
            .withColumn("EVT_mean", col("EVT_mean").cast("double"))
            .withColumn("EVH_mean", col("EVH_mean").cast("double"))
            .withColumn("CH_mean", col("CH_mean").cast("double"))
            .withColumn("TEMP_ave", col("TEMP_ave").cast("double"))
            .withColumn("TEMP_min", col("TEMP_min").cast("double"))
            .withColumn("TEMP_max", col("TEMP_max").cast("double"))

          wildfiresWithFrp.createOrReplaceTempView("wildfires_with_frp")


          val wildfireRDD: SpatialRDD = sparkContext.readCSVPoint(inputFile, "x", "y", '\t')
          val countiesDF = sparkSession.read.format("shapefile").load("tl_2018_us_county.zip")
          val countiesRDD: SpatialRDD = countiesDF.toSpatialRDD
          val wildfireCountyRDD: RDD[(IFeature, IFeature)] = wildfireRDD.spatialJoin(countiesRDD)
          val counties: DataFrame = wildfireCountyRDD.map({ case (wildfire, counties) => Feature.append(wildfire, counties.getAs[String]("GEOID"), "County") })
            .toDataFrame(sparkSession)

          counties.createOrReplaceTempView("counties")


          //convert back to DataFrame
          //val convertedDF: DataFrame = counties.selectExpr("acq_date", "double(split(frp,',')[0]) as frp", "acq_time", "County")
          val convertedDF: DataFrame = wildfiresWithFrp.withColumn("County", lit(""))


          convertedDF.write.mode(SaveMode.Overwrite).parquet(outputFile)

        case _ => validOperation = false
      }
      val t2 = System.nanoTime()
      if (validOperation)
        println(s"Operation '$operation' on file '$inputFile' took ${(t2 - t1) * 1E-9} seconds")
      else
        Console.err.println(s"Invalid operation '$operation'")

    }
    finally {
      sparkSession.stop()
    }
  }
}