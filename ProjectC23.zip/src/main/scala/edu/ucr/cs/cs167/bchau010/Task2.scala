package edu.ucr.cs.cs167.bchau010

import edu.ucr.cs.bdlab.beast.geolite.{Feature, IFeature}
import org.apache.spark.SparkConf
import org.apache.spark.beast.{CRSServer, SparkSQLRegistration}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import scala.collection.Map

/**
 * Scala examples for Beast
 */
object Task2 {
  def main(args: Array[String]): Unit = {
    // Initialize Spark context

    val conf = new SparkConf().setAppName("Beast Example")
    // Set Spark master to local if not already set
    if (!conf.contains("spark.master"))
      conf.setMaster("local[*]")

    val inputfile = args(0)

    // Start the CRSServer and store the information in SparkConf
    val sparkSession: SparkSession = SparkSession.builder().config(conf).getOrCreate()
    val sparkContext = sparkSession.sparkContext
    CRSServer.startServer(sparkContext)
    SparkSQLRegistration.registerUDT
    SparkSQLRegistration.registerUDF(sparkSession)

    try {
      // Load the dataset in the Parquet format
      val wildfireDF = sparkSession.read.parquet(inputfile)

      // Run an SQL query
      wildfireDF.createOrReplaceTempView("wildfire")
      val resultDF = sparkSession.sql(
        s"""
          SELECT County, SUM(frp) AS fire_intensity
          FROM wildfire
          WHERE to_date(acq_date, 'yyyy-MM-dd') BETWEEN to_date('start_date', 'MM/dd/yyyy') AND to_date('end_date', 'MM/dd/yyyy')
          GROUP BY County
        """)

      // Load the county dataset using Beast
      val countyDF = sparkSession.read.format("beast").option("path", "path/to/county_data").load()


      // Join the county dataset with the result of the previous query
      resultDF.createOrReplaceTempView("result")
      countyDF.createOrReplaceTempView("countyDF")
      val finalResultDF = sparkSession.sql(
        """
          SELECT c.NAME AS County, c.g AS geometry, r.fire_intensity
          FROM result r
          JOIN countyDF c ON r.GEOID = c.GEOID
        """)

      // Write the result as a Shapefile
      finalResultDF.coalesce(1).write.format("shapefile").save("wildfireIntensityCounty")

      // Visualization in QGIS

    } finally {
      sparkSession.stop()
    }
  }
}